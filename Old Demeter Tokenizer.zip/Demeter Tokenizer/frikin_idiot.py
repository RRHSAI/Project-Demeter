import pandas as pd
import nltk
from nltk.tokenize import word_tokenize

# Ensure you have the necessary NLTK data files
nltk.download('punkt_tab')

# Load the CSV file
input_csv = 'Demeter Dataset - Unit 1.csv'  # Replace with your CSV file path
output_csv = 'tokenized_output_U1.csv'  # Output file path

# Read the CSV file into a DataFrame
df = pd.read_csv(input_csv)

# Function to tokenize text
def tokenize_text(text):
    return word_tokenize(str(text))

# Tokenize each column
df['problem_tokenized'] = df['Question'].apply(tokenize_text)
df['solution_tokenized'] = df['Answer'].apply(tokenize_text)
df['Incorrect Solution_tokenized'] = df['Incorrect Answer(s)'].apply(tokenize_text)
df['Explanation for correct solution_tokenized'] = df['Reasoning'].apply(tokenize_text)

# Save the tokenized data to a new CSV file
df.to_csv(output_csv, index=False)

print(f"Tokenized data saved to {output_csv}")